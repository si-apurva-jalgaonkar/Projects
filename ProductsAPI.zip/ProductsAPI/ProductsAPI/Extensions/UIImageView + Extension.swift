//
//  UIImageView + Extension.swift
//  ProductsAPI
//
//  Created by Apurva Jalgaonkar on 28/11/23.
//

import UIKit
import Kingfisher

extension UIImageView {
    func setImage(with urlString: String) {
        guard let url = URL.init(string: urlString) else {
            return
        }
        let resource = ImageResource(downloadURL: url, cacheKey: urlString)
        self.kf.indicatorType = .activity
        kf.setImage(with: resource)
    }
}
