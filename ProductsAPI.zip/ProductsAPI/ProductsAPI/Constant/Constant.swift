//
//  Constant.swift
//  ProductsAPI
//
//  Created by Apurva Jalgaonkar on 27/11/23.
//

enum Constant {
    
    enum API {
        static let productURL = "https://fakestoreapi.com/products"
    }
}
